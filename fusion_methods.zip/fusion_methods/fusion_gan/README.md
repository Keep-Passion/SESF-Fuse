# FusionGAN

## Codes for FusionGAN, a GAN model for infrared and visible image fusion 

### Please refer to our following paper for algorithm details:

> Jiayi Ma, Wei Yu, Pengwei Liang, Chang Li, and Junjun Jiang. "FusionGAN: A generative adversarial network for infrared and visible image fusion", Information Fusion, 48, pp. 11-26, Aug. 2019.