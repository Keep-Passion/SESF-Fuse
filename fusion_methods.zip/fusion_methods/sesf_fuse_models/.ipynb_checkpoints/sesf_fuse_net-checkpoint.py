import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as f


class SELayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)


class SESFFuseNet(nn.Module):
    """
    The Class of SESFFuseNet
    """
    def __init__(self, fuse_type = "se_sf_dm"):
        super(SESFFuseNet, self).__init__()
        # Encode
        self.features = self.conv_block(in_channels=1, out_channels=16)
        self.conv_encode_1 = self.conv_block(16, 16)
        self.conv_encode_2 = self.conv_block(32, 16)
        self.conv_encode_3 = self.conv_block(48, 16)
        if(fuse_type == "se_sf_dm"):
            self.se_f = CSELayer(16, 8)
            self.se_1 = CSELayer(16, 8)
            self.se_2 = CSELayer(16, 8)
            self.se_3 = CSELayer(16, 8)
        elif(fuse_type == "sse_sf_dm"):
            self.se_f = SSELayer(16)
            self.se_1 = SSELayer(16)
            self.se_2 = SSELayer(16)
            self.se_3 = SSELayer(16)
        else:
            self.se_f = SCSELayer(16, 8)
            self.se_1 = SCSELayer(16, 8)
            self.se_2 = SCSELayer(16, 8)
            self.se_3 = SCSELayer(16, 8)
        # Decode
        self.conv_decode_1 = self.conv_block(64, 64)
        self.conv_decode_2 = self.conv_block(64, 32)
        self.conv_decode_3 = self.conv_block(32, 16)
        self.conv_decode_4 = self.conv_block(16, 1)

    @staticmethod
    def conv_block(in_channels, out_channels, kernel_size=3):
        """
        The conv block of common setting: conv -> relu -> bn
        In conv operation, the padding = 1
        :param in_channels: int, the input channels of feature
        :param out_channels: int, the output channels of feature
        :param kernel_size: int, the kernel size of feature
        :return:
        """
        block = nn.Sequential(
                    nn.Conv2d(kernel_size=kernel_size, in_channels=in_channels, out_channels=out_channels, padding=1),
                    nn.ReLU(),
                    nn.BatchNorm2d(out_channels),
                )
        return block

    @staticmethod
    def concat(f1, f2):
        """
        Concat two feature in channel direction
        """
        return torch.cat((f1, f2), 1)

    def forward(self, phase, img1, img2=None, fuse_type='se_sf_dm', out_dm=True, kernel_radius=5):
        """
        Train or Forward for two images
        :param phase: str, 'train' or 'fuse'
        :param img1: torch.Tensor
        :param img2: torch.Tensor, only be used in 'fuse' mode
        :param fuse_method: 1 reprsents Average Fuse, 2 represents ABS MAX, 3 represents MAX,
        4 represents L1-Norm Fuse, 5 represents SEDenseSF-Fuse
        :param out_dm: whether or not to return decision map
        :param kernel_size: The kernel length of spatial frequency
        :return: output, torch.Tensor
        """
        if phase == 'train':
            # Encode
            features = self.features(img1)
            se_features = self.se_f(features)
            encode_block1 = self.conv_encode_1(se_features)
            se_encode_block1 = self.se_1(encode_block1)
            se_cat1 = self.concat(se_features, se_encode_block1)
            encode_block2 = self.conv_encode_2(se_cat1)
            se_encode_block2 = self.se_2(encode_block2)
            se_cat2 = self.concat(se_cat1, se_encode_block2)
            encode_block3 = self.conv_encode_3(se_cat2)
            se_encode_block3 = self.se_3(encode_block3)
            se_cat3 = self.concat(se_cat2, se_encode_block3)
            # Decode
            decode_block1 = self.conv_decode_1(se_cat3)
            decode_block2 = self.conv_decode_2(decode_block1)
            decode_block3 = self.conv_decode_3(decode_block2)
            output = self.conv_decode_4(decode_block3)
        elif phase == 'fuse':
            # Encode
            features_1 = self.features(img1)
            features_2 = self.features(img2)
            se_features_1 = self.se_f(features_1)
            se_features_2 = self.se_f(features_2)
            encode_block1_1 = self.conv_encode_1(se_features_1)
            encode_block1_2 = self.conv_encode_1(se_features_2)
            se_encode_block1_1 = self.se_1(encode_block1_1)
            se_encode_block1_2 = self.se_1(encode_block1_2)
            se_cat1_1 = self.concat(se_features_1, se_encode_block1_1)
            se_cat1_2 = self.concat(se_features_2, se_encode_block1_2)
            encode_block2_1 = self.conv_encode_2(se_cat1_1)
            encode_block2_2 = self.conv_encode_2(se_cat1_2)
            se_encode_block2_1 = self.se_2(encode_block2_1)
            se_encode_block2_2 = self.se_2(encode_block2_2)
            se_cat2_1 = self.concat(se_cat1_1, se_encode_block2_1)
            se_cat2_2 = self.concat(se_cat1_2, se_encode_block2_2)
            encode_block3_1 = self.conv_encode_3(se_cat2_1)
            encode_block3_2 = self.conv_encode_3(se_cat2_2)
            se_encode_block3_1 = self.se_3(encode_block3_1)
            se_encode_block3_2 = self.se_3(encode_block3_2)
            se_cat3_1 = self.concat(se_cat2_1, se_encode_block3_1)
            se_cat3_2 = self.concat(se_cat2_2, se_encode_block3_2)
            if fuse_type == 'se_average':    # Average Fuse
                fused_output = self.fusion_average(se_cat3_1, se_cat3_2)
            elif fuse_type == 'se_absmax':   # ABS MAX
                fused_output = self.fusion_abs_max(se_cat3_1, se_cat3_2)
            elif fuse_type == 'se_max':      # MAX
                fused_output = self.fusion_max(se_cat3_1, se_cat3_2)
            elif fuse_type == 'se_l1_norm':  # L1-Norm Fuse
                fused_output = self.fusion_l1_norm(se_cat3_1, se_cat3_2)
            elif fuse_type == 'se_sf' or fuse_type == 'se_sf_dm' or fuse_type == 'sse_sf_dm'or fuse_type == 'scse_sf_dm':  # SEDenseSF-Fuse
                fused_output = self.fusion_channel_sf(se_cat3_1, se_cat3_2, out_dm=out_dm, kernel_radius=kernel_radius)
            if out_dm is False:
                # Decode
                decode_block1 = self.conv_decode_1(fused_output)
                decode_block2 = self.conv_decode_2(decode_block1)
                decode_block3 = self.conv_decode_3(decode_block2)
                output = self.conv_decode_4(decode_block3)
            else:
                output = fused_output
        return output

    @staticmethod
    def fusion_average(f1, f2):
        """
        Perform average operation of two features map
        """
        return (f1 + f2) / 2

    @staticmethod
    def fusion_abs_max(f1, f2):
        """
        Perform abs max operation for each node of two features map
        """
        return torch.where(torch.abs(f1) > torch.abs(f2), f1, f2)

    @staticmethod
    def fusion_max(f1, f2):
        """
        Perform max operation for each node of two features map
        """
        return torch.max(f1, f2)

    @staticmethod
    def fusion_l1_norm(f1, f2):
        """
        Perform l1 norm fusion for each features map
        H. Li, X. J. Wu, “DenseFuse: A Fusion Approach to Infrared and Visible Images,”
        IEEE Trans. Image Process., vol. 28, no. 5, pp. 2614–2623, May. 2019.
        """
        b, c, h, w = f1.shape
        abs_f1 = torch.abs(f1)
        abs_f2 = torch.abs(f2)
        l1_f1 = torch.sum(abs_f1, 1)
        l1_f2 = torch.sum(abs_f2, 1)
        l1_sum = l1_f1 + l1_f2
        w_f1 = l1_f1 / l1_sum
        w_f2 = l1_f2 / l1_sum
        w_f1 = torch.unsqueeze(w_f1, 1)
        w_f2 = torch.unsqueeze(w_f2, 1)
        w_f1 = w_f1.expand(-1, c, -1, -1)
        w_f2 = w_f2.expand(-1, c, -1, -1)
        fused = w_f1 * f1 + w_f2 * f2
        return fused

    # gpu mode
    @staticmethod
    def fusion_channel_sf(f1, f2, out_dm = True, kernel_radius=5):
        """
        Perform channel sf fusion two features
        """
        device = f1.device
        b, c, h, w = f1.shape
        r_shift_kernel = torch.FloatTensor([[0, 0, 0], [1, 0, 0], [0, 0, 0]])\
            .cuda(device).reshape((1, 1, 3, 3)).repeat(c, 1, 1, 1)
        b_shift_kernel = torch.FloatTensor([[0, 1, 0], [0, 0, 0], [0, 0, 0]])\
            .cuda(device).reshape((1, 1, 3, 3)).repeat(c, 1, 1, 1)
        f1_r_shift = f.conv2d(f1, r_shift_kernel, padding=1, groups=c)
        f1_b_shift = f.conv2d(f1, b_shift_kernel, padding=1, groups=c)
        f2_r_shift = f.conv2d(f2, r_shift_kernel, padding=1, groups=c)
        f2_b_shift = f.conv2d(f2, b_shift_kernel, padding=1, groups=c)

        f1_grad = torch.pow((f1_r_shift - f1), 2) + torch.pow((f1_b_shift - f1), 2)
        f2_grad = torch.pow((f2_r_shift - f2), 2) + torch.pow((f2_b_shift - f2), 2)

        kernel_size = kernel_radius * 2 + 1
        add_kernel = torch.ones((c, 1, kernel_size, kernel_size)).float().cuda(device)
        kernel_padding = kernel_size // 2
        f1_sf = torch.sum(f.conv2d(f1_grad, add_kernel, padding=kernel_padding, groups=c), dim=1)
        f2_sf = torch.sum(f.conv2d(f2_grad, add_kernel, padding=kernel_padding, groups=c), dim=1)
        weight_zeros = torch.zeros(f1_sf.shape).cuda(device)
        weight_ones = torch.ones(f1_sf.shape).cuda(device)

        # get decision map
        dm_tensor = torch.where(f1_sf > f2_sf, weight_ones, weight_zeros).cuda(device)
        dm_np = dm_tensor.squeeze().cpu().numpy().astype(np.int)

        if out_dm:
            return dm_np
        else:
            dm_tensor = torch.from_numpy(dm_np).cuda(device).unsqueeze(0).unsqueeze(0).repeat(1, c, 1, 1).type_as(f1)
            f_fused = dm_tensor * f1 + (1 - dm_tensor) * f2
            return f_fused


class DenseSFFuseNet(nn.Module):
    """
    The Class of SESFFuseNet
    """
    def __init__(self):
        super(DenseSFFuseNet, self).__init__()
        # Encode
        self.features = self.conv_block(in_channels=1, out_channels=16)
        self.se_f = SELayer(16, 8)
        self.conv_encode_1 = self.conv_block(16, 16)
        self.se_1 = SELayer(16, 8)
        self.conv_encode_2 = self.conv_block(32, 16)
        self.se_2 = SELayer(16, 8)
        self.conv_encode_3 = self.conv_block(48, 16)
        self.se_3 = SELayer(16, 8)
        # Decode
        self.conv_decode_1 = self.conv_block(64, 64)
        self.conv_decode_2 = self.conv_block(64, 32)
        self.conv_decode_3 = self.conv_block(32, 16)
        self.conv_decode_4 = self.conv_block(16, 1)

    @staticmethod
    def conv_block(in_channels, out_channels, kernel_size=3):
        """
        The conv block of common setting: conv -> relu -> bn
        In conv operation, the padding = 1
        :param in_channels: int, the input channels of feature
        :param out_channels: int, the output channels of feature
        :param kernel_size: int, the kernel size of feature
        :return:
        """
        block = nn.Sequential(
                    nn.Conv2d(kernel_size=kernel_size, in_channels=in_channels, out_channels=out_channels, padding=1),
                    nn.ReLU(),
                    nn.BatchNorm2d(out_channels),
                )
        return block

    @staticmethod
    def concat(f1, f2):
        """
        Concat two feature in channel direction
        """
        return torch.cat((f1, f2), 1)

    def forward(self, phase, img1, img2=None, fuse_type='sedense_sf_dm', out_dm=True, kernel_radius=5):
        """
        Train or Forward for two images
        :param phase: str, 'train' or 'fuse'
        :param img1: torch.Tensor
        :param img2: torch.Tensor, only be used in 'fuse' mode
        :param fuse_method: 1 reprsents Average Fuse, 2 represents ABS MAX, 3 represents MAX,
        4 represents L1-Norm Fuse, 5 represents SEDenseSF-Fuse
        :param out_dm: whether or not to return decision map
        :param kernel_size: The kernel length of spatial frequency
        :return: output, torch.Tensor
        """
        if phase == 'train':
            # Encode (no se)
            features = self.features(img1)
            encode_block1 = self.conv_encode_1(features)
            cat1 = self.concat(features, encode_block1)
            encode_block2 = self.conv_encode_2(cat1)
            cat2 = self.concat(cat1, encode_block2)
            encode_block3 = self.conv_encode_3(cat2)
            cat3 = self.concat(cat2, encode_block3)
            # Decode (no se)
            decode_block1 = self.conv_decode_1(cat3)
            decode_block2 = self.conv_decode_2(decode_block1)
            decode_block3 = self.conv_decode_3(decode_block2)
            output = self.conv_decode_4(decode_block3)
        elif phase == 'fuse':
            # Encode (no se)
            features_x = self.features(img1)
            features_y = self.features(img2)
            encode_block1_x = self.conv_encode_1(features_x)
            encode_block1_y = self.conv_encode_1(features_y)
            cat1_x = self.concat(features_x, encode_block1_x)
            cat1_y = self.concat(features_y, encode_block1_y)
            encode_block2_x = self.conv_encode_2(cat1_x)
            encode_block2_y = self.conv_encode_2(cat1_y)
            cat2_x = self.concat(cat1_x, encode_block2_x)
            cat2_y = self.concat(cat1_y, encode_block2_y)
            encode_block3_x = self.conv_encode_3(cat2_x)
            encode_block3_y = self.conv_encode_3(cat2_y)
            encode_output_x = self.concat(cat2_x, encode_block3_x)
            encode_output_y = self.concat(cat2_y, encode_block3_y)
            if fuse_type == 'dense_average':    # Average Fuse
                fused_output = self.fusion_average(encode_output_x, encode_output_y)
            elif fuse_type == 'dense_absmax':   # ABS MAX
                fused_output = self.fusion_abs_max(encode_output_x, encode_output_y)
            elif fuse_type == 'dense_max':      # MAX
                fused_output = self.fusion_max(encode_output_x, encode_output_y)
            elif fuse_type == 'dense_l1-norm':  # L1-Norm Fuse
                fused_output = self.fusion_l1_norm(encode_output_x, encode_output_y)
            elif fuse_type == 'dense_sf' or fuse_type == 'dense_sf_dm' :  # SEDenseSF-Fuse
                fused_output = self.fusion_channel_sf(encode_output_x, encode_output_y, out_dm=out_dm, kernel_radius=kernel_radius)
            if out_dm is False:
                # Decode
                decode_block1 = self.conv_decode_1(fused_output)
                decode_block2 = self.conv_decode_2(decode_block1)
                decode_block3 = self.conv_decode_3(decode_block2)
                output = self.conv_decode_4(decode_block3)
            else:
                output = fused_output
        return output

    @staticmethod
    def fusion_average(f1, f2):
        """
        Perform average operation of two features map
        """
        return (f1 + f2) / 2

    @staticmethod
    def fusion_abs_max(f1, f2):
        """
        Perform abs max operation for each node of two features map
        """
        return torch.where(torch.abs(f1) > torch.abs(f2), f1, f2)

    @staticmethod
    def fusion_max(f1, f2):
        """
        Perform max operation for each node of two features map
        """
        return torch.max(f1, f2)

    @staticmethod
    def fusion_l1_norm(f1, f2):
        """
        Perform l1 norm fusion for each features map
        H. Li, X. J. Wu, “DenseFuse: A Fusion Approach to Infrared and Visible Images,”
        IEEE Trans. Image Process., vol. 28, no. 5, pp. 2614–2623, May. 2019.
        """
        b, c, h, w = f1.shape
        abs_f1 = torch.abs(f1)
        abs_f2 = torch.abs(f2)
        l1_f1 = torch.sum(abs_f1, 1)
        l1_f2 = torch.sum(abs_f2, 1)
        l1_sum = l1_f1 + l1_f2
        w_f1 = l1_f1 / l1_sum
        w_f2 = l1_f2 / l1_sum
        w_f1 = torch.unsqueeze(w_f1, 1)
        w_f2 = torch.unsqueeze(w_f2, 1)
        w_f1 = w_f1.expand(-1, c, -1, -1)
        w_f2 = w_f2.expand(-1, c, -1, -1)
        fused = w_f1 * f1 + w_f2 * f2
        return fused

    # gpu mode
    @staticmethod
    def fusion_channel_sf(f1, f2, out_dm=True, kernel_radius=5):
        """
        Perform channel sf fusion two features
        """
        device = f1.device
        b, c, h, w = f1.shape
        r_shift_kernel = torch.FloatTensor([[0, 0, 0], [1, 0, 0], [0, 0, 0]])\
            .cuda(device).reshape((1, 1, 3, 3)).repeat(c, 1, 1, 1)
        b_shift_kernel = torch.FloatTensor([[0, 1, 0], [0, 0, 0], [0, 0, 0]])\
            .cuda(device).reshape((1, 1, 3, 3)).repeat(c, 1, 1, 1)
        f1_r_shift = f.conv2d(f1, r_shift_kernel, padding=1, groups=c)
        f1_b_shift = f.conv2d(f1, b_shift_kernel, padding=1, groups=c)
        f2_r_shift = f.conv2d(f2, r_shift_kernel, padding=1, groups=c)
        f2_b_shift = f.conv2d(f2, b_shift_kernel, padding=1, groups=c)

        f1_grad = torch.pow((f1_r_shift - f1), 2) + torch.pow((f1_b_shift - f1), 2)
        f2_grad = torch.pow((f2_r_shift - f2), 2) + torch.pow((f2_b_shift - f2), 2)

        kernel_size = kernel_radius * 2 + 1
        add_kernel = torch.ones((c, 1, kernel_size, kernel_size)).float().cuda(device)
        kernel_padding = kernel_size // 2
        f1_sf = torch.sum(f.conv2d(f1_grad, add_kernel, padding=kernel_padding, groups=c), dim=1)
        f2_sf = torch.sum(f.conv2d(f2_grad, add_kernel, padding=kernel_padding, groups=c), dim=1)
        weight_zeros = torch.zeros(f1_sf.shape).cuda(device)
        weight_ones = torch.ones(f1_sf.shape).cuda(device)

        # get decision map
        dm_tensor = torch.where(f1_sf > f2_sf, weight_ones, weight_zeros).cuda(device)
        dm_np = dm_tensor.squeeze().cpu().numpy().astype(np.int)

        if out_dm:
            return dm_np
        else:
            dm_tensor = torch.from_numpy(dm_np).cuda(device).unsqueeze(0).unsqueeze(0).repeat(1, c, 1, 1).type_as(f1)
            f_fused = dm_tensor * f1 + (1 - dm_tensor) * f2
            return f_fused
        
class CSELayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(CSELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)
class SSELayer(nn.Module):
    def __init__(self, channel):
        super(SSELayer, self).__init__()
        self.fc = nn.Sequential(
            nn.Conv2d(channel, 1, kernel_size=1, bias=False),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        y = self.fc(x) 
        return x * y 
class SCSELayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SCSELayer, self).__init__()
        self.CSE = CSELayer(channel, reduction=reduction)
        self.SSE = SSELayer(channel)

    def forward(self, U):
        SSE = self.SSE(U)
        CSE = self.CSE(U)
        return SSE+CSE

