import os
import numpy as np
import torch
import torchvision.transforms as transforms
from skimage.color import rgb2ycbcr

from fusion_methods.deep_fuse_models.lib.utils import fusePostProcess
from fusion_methods.deep_fuse_models.lib.loss  import MEF_SSIM_Loss
from fusion_methods.deep_fuse_models.lib.model import DeepFuse
import fusion_methods.deep_fuse_models.torchvision_sunner.transforms as sunnertransforms

ops = transforms.Compose([
    sunnertransforms.ToTensor(),
    sunnertransforms.ToFloat(),
    sunnertransforms.Transpose(sunnertransforms.BHWC2BCHW),
    sunnertransforms.Normalize(),
])

def deep_fuse_forward(img1, img2, pre_train_model_path=""):
    # Prepare image
    ndim = img1.ndim
    if ndim == 2: # gray mode
        img1 = np.repeat(np.expand_dims(img1, axis=2), 3, axis=2)
        img2 = np.repeat(np.expand_dims(img2, axis=2), 3, axis=2)
    else:         # color mode
        img1 = rgb2ycbcr(img1)
        img2 = rgb2ycbcr(img2)
    img1 = torch.unsqueeze(ops(img1), 0)
    img2 = torch.unsqueeze(ops(img2), 0)
    # Load the pre-trained model
    model = DeepFuse()
    state = torch.load(pre_train_model_path)
    model.load_state_dict(state['model'])
    model.cuda()
    model.eval()
    criterion = MEF_SSIM_Loss().cuda()

    # Fuse!
    with torch.no_grad():
        # Forward
        img1, img2 = img1.cuda(), img2.cuda()
        img1_lum = img1[:, 0:1]
        img2_lum = img2[:, 0:1]
        model.setInput(img1_lum, img2_lum)
        y_f  = model.forward()
        _, y_hat = criterion(y_1 = img1_lum, y_2 = img2_lum, y_f = y_f)
        img, y_f_out = fusePostProcess(y_f, y_hat, img1, img2, single=True)
        if ndim == 2:
            fused = y_f_out[0, 0, :, :]
        else:
            fused = img[0, :, :,:]

    return np.squeeze(fused).astype(np.uint8)