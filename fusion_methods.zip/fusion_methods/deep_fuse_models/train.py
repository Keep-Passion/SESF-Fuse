from lib.dataset import BracketedDataset
from lib.utils import INFO, fusePostProcess
from lib.loss  import MEF_SSIM_Loss
from lib.model import DeepFuse
from opts  import TrainOptions

import torchvision_sunner.transforms as sunnertransforms
import torchvision_sunner.data as sunnerData
import torchvision.transforms as transforms

from matplotlib import pyplot as plt
from torch.optim import Adam
from tqdm import tqdm

import numpy as np
import torch
import cv2
import os

"""
    This script defines the training procedure of DeepFuse

    Author: SunnerLi
"""

def train(opts):
    # Create the loader
    loader_train = sunnerData.DataLoader(
        dataset = BracketedDataset(
            root = os.path.join(opts.folder, 'Bracketed_images_train'),
            crop_size = opts.crop_size,
            transform = transforms.Compose([
                sunnertransforms.ToTensor(),
                sunnertransforms.ToFloat(),
                sunnertransforms.Transpose(sunnertransforms.BHWC2BCHW),
                sunnertransforms.Normalize(),
            ])
        ), batch_size = opts.batch_size, shuffle = True, num_workers = 0
    )

    loader_val = sunnerData.DataLoader(
        dataset = BracketedDataset(
            root = os.path.join(opts.folder, 'Bracketed_images_val'),
            crop_size = opts.crop_size,
            transform = transforms.Compose([
                sunnertransforms.ToTensor(),
                sunnertransforms.ToFloat(),
                sunnertransforms.Transpose(sunnertransforms.BHWC2BCHW),
                sunnertransforms.Normalize(),
            ])
        ), batch_size = opts.batch_size, shuffle = True, num_workers = 0
    )

    # Create the model
    model = DeepFuse(device = opts.device)
    criterion = MEF_SSIM_Loss().to(opts.device)
    optimizer = Adam(model.parameters(), lr = 0.0001)

    # Load pre-train model
    if os.path.exists(opts.resume):
        state = torch.load(opts.resume)
        Loss_list = state['loss']
        model.load_state_dict(state['model'])
    else:
        Loss_list = []

    Loss_list_val = []  # 用于验证
    min_loss = 100000000.0

    bar = tqdm(range(opts.epoch))
    for ep in bar:
        # 训练
        loss_list = []
        for (patch1, patch2) in loader_train:
            # Extract the luminance and move to computation device
            patch1, patch2 = patch1.to(opts.device), patch2.to(opts.device)
            patch1_lum = patch1[:, 0:1]
            patch2_lum = patch2[:, 0:1]
            # Forward and compute loss
            model.train()  # 训练
            model.setInput(patch1_lum, patch2_lum)
            y_f  = model.forward()
            loss, y_hat = criterion(y_1 = patch1_lum, y_2 = patch2_lum, y_f = y_f)
            loss_list.append(loss.item())
            bar.set_description("Epoch: %d   Loss: %.6f" % (ep, loss_list[-1]))
            # Update the parameters
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        Loss_list.append(np.mean(loss_list))
        # Save the training image
        if ep % opts.record_epoch == 0:
            img, y_f_out = fusePostProcess(y_f, y_hat, patch1, patch2, single = False)
            cv2.imwrite(os.path.join(opts.det, 'image', str(ep) + ".png"), img[0, :, :, :])

        # 验证
        loss_list_val = []
        for (patch1, patch2) in loader_val:
            # Extract the luminance and move to computation device
            patch1, patch2 = patch1.to(opts.device), patch2.to(opts.device)
            patch1_lum = patch1[:, 0:1]
            patch2_lum = patch2[:, 0:1]
            # Forward and compute loss
            model.eval()  # 验证
            model.setInput(patch1_lum, patch2_lum)
            y_f = model.forward()
            loss, y_hat = criterion(y_1=patch1_lum, y_2=patch2_lum, y_f=y_f)
            loss_list_val.append(loss.item())
            bar.set_description("Epoch: %d   Loss: %.6f  validation" % (ep, loss_list_val[-1]))
        Loss_list_val.append(np.mean(loss_list_val))

        # Save the best training model
        if Loss_list_val[-1] < min_loss:
            best_state = {
                'model': model.state_dict(),
                'loss' : Loss_list[-1]
            }
            torch.save(best_state, os.path.join(opts.det, 'model', 'best_model.pth'))

        # Save the training model
        model_name = str(ep) + ".pth"

        state = {
            'model': model.state_dict(),
            'loss' : Loss_list[-1]
        }
        torch.save(state, os.path.join(opts.det, 'model', model_name))

    # Plot the loss curve
    plt.clf()
    plt.plot(Loss_list, '-')
    plt.title("loss curve")
    plt.savefig(os.path.join(opts.det, 'image', "curve.png"))

    # Plot the loss curve for validation
    plt.clf()
    plt.plot(Loss_list_val, '-')
    plt.title("loss curve for validation")
    plt.savefig(os.path.join(opts.det, 'image', "curve_validation.png"))

    # train and val loss
    plt.figure()
    plt.plot(Loss_list, color='r', label='train loss')
    plt.plot(Loss_list_val, color='b', label='val loss')
    plt.legend(loc='best')
    plt.xlabel('epochs')
    plt.ylabel('Loss')
    plt.title('Train and Val Loss', fontsize=16)
    plt.savefig(os.path.join(opts.det, 'image', "train_and_val_loss.png"))
    plt.show()


if __name__ == '__main__':
    opts = TrainOptions().parse()
    train(opts)
