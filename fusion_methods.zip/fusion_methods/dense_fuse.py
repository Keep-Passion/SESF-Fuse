import os
import tensorflow as tf
import numpy as np
from fusion_methods.dense_fuse_models.fusion_l1norm import L1_norm
from fusion_methods.dense_fuse_models.dense_fuse_net import DenseFuseNet


def dense_fuse_forward(img1, img2, ssim_weight_index=3, type="l1"):
    """
    densefuse
    The codes are copied from https://github.com/hli1221/imagefusion_densefuse
    We modified the author's code in order to ensemble them.
    H. Li, X. J. Wu, “DenseFuse: A Fusion Approach to Infrared and Visible Images,”
    IEEE Trans. Image Process., vol. 28, no. 5, pp. 2614–2623, May. 2019.
    :param img1: last image, np.array
    :param img2: next image, np.array
    :param ssim_weight_index: 0 or 1 or 2 or 3 which represent 1,10,100,1000 of weight in loss
    :param type: "l1" or "add" string
    :return: fused result, np.array
    """
    fused = np.zeros(img1.shape)
    ndim = img1.ndim  # Commonly used for rgb and gray
    shape = img1.shape # Commonly used for rgb and gray
    model_path = os.path.join(os.getcwd(), "fusion_methods", "dense_fuse_models", "ckpt",
                              "densefuse_model_bs2_epoch4_all_weight_1e{}.ckpt".format(ssim_weight_index))
    img1 = np.expand_dims(np.expand_dims(img1, axis=img1.ndim), axis=0).astype(float)
    img2 = np.expand_dims(np.expand_dims(img2, axis=img2.ndim), axis=0).astype(float)
    with tf.Graph().as_default(), tf.Session() as sess:
        img1_ph = tf.placeholder(tf.float32, shape=(1, shape[0], shape[1], 1), name='img1')
        img2_ph = tf.placeholder(tf.float32, shape=(1, shape[0], shape[1], 1), name='img2')
        dfn = DenseFuseNet(None)
        # restore the trained model
        saver = tf.train.Saver()
        saver.restore(sess, model_path)
        if type == "add":
            output_image = dfn.transform_addition(img1_ph, img2_ph)
            if ndim == 2: # gray mode
                fused = sess.run(output_image, feed_dict={img1_ph: img1, img2_ph: img2})
            elif ndim == 3: # RGB mode
                output0 = sess.run(output_image, feed_dict={img1_ph: img1[:, :, :, 0], img2_ph: img2[:, :, :, 0]})
                output1 = sess.run(output_image, feed_dict={img1_ph: img1[:, :, :, 1], img2_ph: img2[:, :, :, 1]})
                output2 = sess.run(output_image, feed_dict={img1_ph: img1[:, :, :, 2], img2_ph: img2[:, :, :, 2]})
                fused = np.stack((output0, output1, output2), axis=3)
        elif type == "l1":
            enc_img1 = dfn.transform_encoder(img1_ph)
            enc_img2 = dfn.transform_encoder(img2_ph)
            target = tf.placeholder(
                tf.float32, shape=enc_img1.shape, name='target')
            output_image = dfn.transform_decoder(target)
            if ndim == 2:    # gray mode
                enc_img1_temp, enc_img2_temp = sess.run([enc_img1, enc_img2], feed_dict={
                    img1_ph: img1, img2_ph: img2})
                feature = L1_norm(enc_img1_temp, enc_img2_temp)
                fused = sess.run(output_image, feed_dict={target: feature})
            elif ndim == 3:  # RGB mode
                enc_img1_temp, enc_img2_temp = sess.run([enc_img1, enc_img2], feed_dict={
                    img1_ph: img1[:, :, :, 0], img2_ph: img2[:, :, :, 0]})
                feature = L1_norm(enc_img1_temp, enc_img2_temp)
                output0 = sess.run(output_image, feed_dict={target: feature})

                enc_img1_temp, enc_img2_temp = sess.run([enc_img1, enc_img2], feed_dict={
                    img1_ph: img1[:, :, :, 1], img2_ph: img2[:, :, :, 1]})
                feature = L1_norm(enc_img1_temp, enc_img2_temp)
                output1 = sess.run(output_image, feed_dict={target: feature})

                enc_img1_temp, enc_img2_temp = sess.run([enc_img1, enc_img2], feed_dict={
                    img1_ph: img1[:, :, :, 2], img2_ph: img2[:, :, :, 2]})
                feature = L1_norm(enc_img1_temp, enc_img2_temp)
                output2 = sess.run(output_image, feed_dict={target: feature})
                fused = np.stack((output0, output1, output2), axis=3)
    fused = np.squeeze(fused)
    # The author of densefuse use scipy.misc.imsave to ouput image, which will rescale float value
    # to range [0,255], however, we prefer to use skimage.io.imsave which would ensure to save value
    # what i really want.
    cmax = np.amax(fused)
    cmin = np.amin(fused)
    fused = (fused * 1.0 - cmin) * (255 - 0) / (cmax - cmin)
    # return np.squeeze(fused).clip(0, 255).astype(np.uint8)
    return np.squeeze(fused).astype(np.uint8)
