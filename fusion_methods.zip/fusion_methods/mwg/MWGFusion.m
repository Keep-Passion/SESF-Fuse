% MWGFFusion.m
% -------------------------------------------------------------------
% 
% Date:    27/04/2013
% Last modified: 29/10/2013
% -------------------------------------------------------------------
function imgRec = MWGFusion(img1, img2)
    %% ---- The parameters -----
    % ----------- the multi scale -----
    para.Scale.lsigma = 4;
    para.Scale.ssigma = 0.5;
    para.Scale.alpha = 0.5;
    % -------------- the Merge parameter fusion of registered images-------------
    para.Merge.per = 0.5;
    para.Merge.margin = 1.5*para.Scale.lsigma;
    para.Merge.method = 2;
    % ------------- the Reconstruct parameter -----------
    para.Rec.iter = 500;
    para.Rec.res = 1e-6;
    para.Rec.modify = 5;
    para.Rec.iniMode = 'weight';
    %% ----------------- Compute the weights ------------------
    if size(img1, 3) == 1,
        img1Gray = img1;
        img2Gray = img2;
    else 
        img1Gray = RGBTOGRAY(img1);
        img2Gray = RGBTOGRAY(img2);
    end
    % ----- Compute the gradient ------
    [dx1, dy1] = GradientMethod(img1Gray, 'zhou'); 
    [dx2, dy2] = GradientMethod(img2Gray, 'zhou');
    dxdy1 = dx1+1i*dy1;
    dxdy2 = dx2+1i*dy2;
    
    para.Merge.oppo = 0;
    [~, ~, wt1, wt2] = WeightGradient(imresize(dxdy1, 0.25), imresize(dxdy2, 0.25), para);
    aa = wt1>wt2+eps;
    if sum(aa(:))/numel(wt1) > 0.5,
        para.Merge.oppo = 1;
    end
  
    % Compute the Large and small scale structure saliency Q
    para.LScale.sigma = para.Scale.lsigma;
    para.LScale.alpha = para.Scale.alpha;
    if isfield(para, 'LScale'),
        [~, ~, wtL1, wtL2] = WeightGradient(dxdy1, dxdy2, para.LScale); 
    end  
    
    para.SScale.sigma = para.Scale.ssigma;
    para.SScale.alpha = para.Scale.alpha;
    if isfield(para, 'SScale'),
        [~, ~, wtS1, wtS2] = WeightGradient(dxdy1, dxdy2, para.SScale); 
    else
        error('The scale must have the small scale');
    end
    
    % Combining multi-scale information 
    if exist('wtL1', 'var'),
        wt1 = MergeWeights(wtL1, wtL2, wtS1, wtS2, para.Merge);
        ww1 = ordfilt2(wt1, 5, ones(3, 3));
        ww2 = 1 - ww1;
    else
        ww1 = wtS1 ./ (wtS1 + wtS2 +eps);
        ww2 = 1-ww1;
    end
    
    
    %% ----------------- Weighted gradient-based fusion --------------------
    imgRec = zeros(size(img1));
    for ii = 1:size(img1, 3),
        [dx1, dy1] = GradientMethod(img1(:, :, ii), 'zhou'); 
        [dx2, dy2] = GradientMethod(img2(:, :, ii), 'zhou');
        
        dxdy1 = dx1+1i*dy1;
        dxdy2 = dx2+1i*dy2;
        dxdy = GradientMixWeightModify(dxdy1, dxdy2, ww1, ww2, para.Rec.modify);
        
        imgRec(:, :, ii) = RecByGraInitial(img1(:, :, ii), img2(:, :, ii), ww1, ww2, dxdy, para.Rec.iter, para.Rec.res, 0.1, para.Rec.iniMode);
    end
    
    %%
    imgRec = min(imgRec, 255);
    imgRec = max(imgRec, 0);
    imgRec = round(imgRec);
end

