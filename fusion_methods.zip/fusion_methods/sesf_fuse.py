import os
import torch
import numpy as np
import PIL.Image
from skimage import morphology
import torchvision.transforms as transforms
from skimage.color import rgb2gray
from fusion_methods.sesf_fuse_models.sesf_fuse_net import SESFFuseNet, DenseSFFuseNet


def sesf_fuse_forward(img1, img2, fuse_type="se_sf_dm"):
    # model setting
    ndim = img1.ndim
    mean_value = 0.4500517361627943
    std_value = 0.26465333914691797
    device = "cuda:0"
    data_transforms = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize([mean_value], [std_value])
    ])

    if fuse_type == "dense_sf_dm":
        model_path = os.path.join(os.getcwd(), 'fusion_methods', 'sesf_fuse_models',
                                  'pkl', 'dense_lp_lssim_1e3_batch30_epoch48.pkl')
        model = DenseSFFuseNet()
        model.load_state_dict(torch.load(model_path, map_location={'cuda:1': 'cuda:0'}))
    else:
        model_path = os.path.join(os.getcwd(), 'fusion_methods', 'sesf_fuse_models',
                                  'pkl', 'se_lp_lssim_1e3_batch30_epoch48.pkl')
        model = SESFFuseNet()
        model.load_state_dict(torch.load(model_path, map_location={'cuda:3': 'cuda:0'}))

    model.to(device)
    model.eval()

    # fusion Setting
    out_dm = False
    if 'dm' in fuse_type:
        out_dm = True
    kernel_radius = 5
    area_ratio = 0.01
    gf_radius = 4
    gf_eps = 0.1

    if ndim == 2:  # Gray mode
        img1_gray = img1
        img2_gray = img2
    else:               # Color mode
        img1_gray = rgb2gray(img1)
        img2_gray = rgb2gray(img2)

    img1_gray_pil = PIL.Image.fromarray(img1_gray)
    img2_gray_pil = PIL.Image.fromarray(img2_gray)
    img1_gray_tensor = data_transforms(img1_gray_pil).unsqueeze(0)
    img2_gray_tensor = data_transforms(img2_gray_pil).unsqueeze(0)
    if out_dm is False and img1.ndim == 3:
        img1_color_tensor = torch.zeros((1, 3, img1.shape[0], img1.shape[1])).float()
        img2_color_tensor = torch.zeros((1, 3, img2.shape[0], img2.shape[1])).float()
        for channel_index in range(ndim):
            img1_color_tensor[:, channel_index, :, :] = \
                data_transforms(PIL.Image.fromarray(img1[:, :, channel_index])).unsqueeze(0)
            img2_color_tensor[:, channel_index, :, :] = \
                data_transforms(PIL.Image.fromarray(img2[:, :, channel_index])).unsqueeze(0)

    fused = np.zeros_like(img1)
    with torch.no_grad():
        if ndim == 2:  # Gray mode
            input1_tensor = img1_gray_tensor.to(device)
            input2_tensor = img2_gray_tensor.to(device)
            output = model.forward('fuse', input1_tensor, input2_tensor,
                                   fuse_type=fuse_type, out_dm=out_dm, kernel_radius=kernel_radius)
            if out_dm is False:
                fused = output.squeeze(0).squeeze(0).cpu().numpy()
                fused = ((fused * std_value) + mean_value) * 255.0
            else:
                dm = output
                dm = dm_filter(dm, area_ratio=area_ratio, ks=kernel_radius)
                temp_fused = img1 * dm + img2 * (1 - dm)
                dm = guided_filter(temp_fused, dm, gf_radius, eps=gf_eps)
                fused = img1 * 1.0 * dm + img2 * 1.0 * (1 - dm)
        else:          # Color mode
            if out_dm is False:
                for channel_index in range(ndim):
                    input1_tensor = img1_color_tensor[:, channel_index, :, :].to(device).unsqueeze(1)
                    input2_tensor = img2_color_tensor[:, channel_index, :, :].to(device).unsqueeze(1)
                    output = model.forward('fuse', input1_tensor, input2_tensor,
                                           fuse_type=fuse_type, out_dm=out_dm, kernel_radius=kernel_radius)
                    fused[:, :, channel_index] = \
                        ((output.squeeze(0).squeeze(0).cpu().numpy() * std_value) + mean_value) * 255.0
            else:
                input1_tensor = img1_gray_tensor.to(device)
                input2_tensor = img2_gray_tensor.to(device)
                output = model.forward('fuse', input1_tensor, input2_tensor,
                                       fuse_type=fuse_type, out_dm=out_dm, kernel_radius=kernel_radius)
                dm = output
                dm = dm_filter(dm, area_ratio=area_ratio, ks=kernel_radius)
                dm = np.expand_dims(dm, axis=2)
                temp_fused = img1 * dm + img2 * (1 - dm)
                dm = guided_filter(temp_fused, dm, gf_radius, eps=gf_eps)
                fused = img1 * 1.0 * dm + img2 * 1.0 * (1 - dm)
        fused = np.clip(fused, 0, 255).astype(np.uint8)
    return fused


def dm_filter(in_dm, area_ratio=0.01, ks=5):
    # Morphology filter and Small region removal
    h, w = in_dm.shape[:2]
    se = morphology.disk(ks)  # 'disk' kernel with ks size for structural element
    out_dm = morphology.binary_opening(in_dm, se)
    out_dm = morphology.remove_small_holes(out_dm == 0, area_ratio * h * w)
    out_dm = np.where(out_dm, 0, 1)
    out_dm = morphology.binary_closing(out_dm, se)
    out_dm = morphology.remove_small_holes(out_dm == 1, area_ratio * h * w)
    out_dm = np.where(out_dm, 1, 0)
    return out_dm


# Guided Filter
def box_filter(imgSrc, r):
    """
    Definition imDst(x, y)=sum(sum(imSrc(x-r:x+r,y-r:y+r)));
    :param imgSrc:
    :param r:
    :return:
    """
    if imgSrc.ndim == 2:
        h, w = imgSrc.shape[:2]
        imDst = np.zeros(imgSrc.shape[:2])

        # cumulative sum over h axis
        imCum = np.cumsum(imgSrc, axis=0)
        # difference over h axis
        imDst[0: r+1] = imCum[r: 2 * r+1]
        imDst[r + 1: h - r] = imCum[2 * r + 1: h] - imCum[0: h - 2 * r - 1]
        imDst[h - r: h, :] = np.tile(imCum[h - 1, :], [r, 1]) - imCum[h - 2 * r - 1: h - r - 1, :]

        # cumulative sum over w axis
        imCum = np.cumsum(imDst, axis=1)

        # difference over w axis
        imDst[:, 0: r + 1] = imCum[:, r: 2 * r + 1]
        imDst[:, r + 1: w - r] = imCum[:, 2 * r + 1: w] - imCum[:, 0: w - 2 * r - 1]
        imDst[:, w - r: w] = np.tile(np.expand_dims(imCum[:, w - 1], axis=1), [1, r]) - \
                             imCum[:, w - 2 * r - 1: w - r - 1]
    else:
        h, w = imgSrc.shape[:2]
        imDst = np.zeros(imgSrc.shape)

        # cumulative sum over h axis
        imCum = np.cumsum(imgSrc, axis=0)
        # difference over h axis
        imDst[0: r + 1] = imCum[r: 2 * r + 1]
        imDst[r + 1: h - r, :] = imCum[2 * r + 1: h, :] - imCum[0: h - 2 * r - 1, :]
        imDst[h - r: h, :] = np.tile(imCum[h - 1, :], [r, 1, 1]) - imCum[h - 2 * r - 1: h - r - 1, :]

        # cumulative sum over w axis
        imCum = np.cumsum(imDst, axis=1)

        # difference over w axis
        imDst[:, 0: r + 1] = imCum[:, r: 2 * r + 1]
        imDst[:, r + 1: w - r] = imCum[:, 2 * r + 1: w] - imCum[:, 0: w - 2 * r - 1]
        imDst[:, w - r: w] = np.tile(np.expand_dims(imCum[:, w - 1], axis=1), [1, r, 1]) - \
                             imCum[:, w - 2 * r - 1: w - r - 1]
    return imDst


def guided_filter(I, p, r=4, eps=0.1):
    h, w = I.shape[:2]
    if I.ndim == 2:
        N = box_filter(np.ones((h, w)), r)
    else:
        N = box_filter(np.ones((h, w, 1)), r)
    mean_I = box_filter(I, r) / N
    mean_p = box_filter(p, r) / N
    mean_Ip = box_filter(I * p, r) / N
    cov_Ip = mean_Ip - mean_I * mean_p
    mean_II = box_filter(I * I, r) / N
    var_I = mean_II - mean_I * mean_I
    a = cov_Ip / (var_I + eps)

    if I.ndim == 2:
        b = mean_p - a * mean_I
        mean_a = box_filter(a, r) / N
        mean_b = box_filter(b, r) / N
        q = mean_a * I + mean_b
    else:
        b = mean_p - np.expand_dims(np.sum((a * mean_I), 2), 2)
        mean_a = box_filter(a, r) / N
        mean_b = box_filter(b, r) / N
        q = np.expand_dims(np.sum(mean_a * I, 2), 2) + mean_b
    return q
