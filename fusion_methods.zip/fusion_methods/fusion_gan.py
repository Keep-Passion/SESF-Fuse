import numpy as np
import tensorflow as tf
from skimage.color import rgb2ycbcr


def fusion_gan_forward(img1, img2, reader_path):
    """
    Fusion Gan
    The codes are copied from https://github.com/jiayi-ma/FusionGAN
    Jiayi Ma, Wei Yu, Pengwei Liang, Chang Li, and Junjun Jiang. "FusionGAN: A generative adversarial network for infrared and visible image fusion",
    Information Fusion, 48, pp. 11-26, Aug. 2019.
    :param img1: last image, np.array
    :param img2: next image, np.array
    :param reader_path: ckpt path dir
    :return: fused result, np.array
    """
    ndim = img1.ndim
    if ndim == 2:
        img1 = img1.astype(np.float)
        img2 = img2.astype(np.float)
    else:
        img1 = rgb2ycbcr(img1).astype(np.float)[:, :, 0]
        img2 = rgb2ycbcr(img2).astype(np.float)[:, :, 0]
    reader = tf.train.NewCheckpointReader(reader_path)
    with tf.name_scope('IR_input'):
        images_ir = tf.placeholder(tf.float32, [1, None, None, None], name='images_ir')
    with tf.name_scope('VI_input'):
        images_vi = tf.placeholder(tf.float32, [1, None, None, None], name='images_vi')

    with tf.name_scope('input'):
        input_image = tf.concat([images_ir, images_vi], axis=-1)
    with tf.name_scope('fusion'):
        fusion_image = _fusion_model(input_image, reader)

    with tf.Session() as sess:
        init_op = tf.global_variables_initializer()
        sess.run(init_op)
        data_ir, data_vi = _input_setup(img1, img2)
        result = sess.run(fusion_image, feed_dict={images_ir: data_ir, images_vi: data_vi})
        result = result * 127.5 + 127.5
        result = result.squeeze()
        cmax = np.amax(result)
        cmin = np.amin(result)
        result = (result * 1.0 - cmin) * (255 - 0) / (cmax - cmin)
    tf.reset_default_graph()
    return result.astype(np.uint8)


def _input_setup(img1, img2):
    """
    Data pre processing for fusion gan
    :param img1: np.array
    :param img2: np.array
    :return:train_data_ir, train_data_vi, processing result
    """
    padding = 6
    sub_ir_sequence = []
    sub_vi_sequence = []
    input_ir = (img1 - 127.5) / 127.5
    input_ir = np.lib.pad(input_ir, ((padding, padding), (padding, padding)), 'edge')
    w, h = input_ir.shape
    input_ir = input_ir.reshape([w, h, 1])
    input_vi = (img2 - 127.5) / 127.5
    input_vi = np.lib.pad(input_vi, ((padding, padding), (padding, padding)), 'edge')
    w, h = input_vi.shape
    input_vi = input_vi.reshape([w, h, 1])
    sub_ir_sequence.append(input_ir)
    sub_vi_sequence.append(input_vi)
    train_data_ir = np.asarray(sub_ir_sequence)
    train_data_vi = np.asarray(sub_vi_sequence)
    return train_data_ir, train_data_vi


def _lrelu(x, leak=0.2):
    return tf.maximum(x, leak * x)


def _fusion_model(img, reader):
    """
    Fusion Gan model
    :param img: np.array
    :param reader:
    :return:
    """
    with tf.variable_scope('fusion_model'):
        with tf.variable_scope('layer1'):
            weights = tf.get_variable("w1", initializer=tf.constant(reader.get_tensor('fusion_model/layer1/w1')))
            bias = tf.get_variable("b1", initializer=tf.constant(reader.get_tensor('fusion_model/layer1/b1')))
            conv1_ir = tf.contrib.layers.batch_norm(
                tf.nn.conv2d(img, weights, strides=[1, 1, 1, 1], padding='VALID') + bias, decay=0.9,
                updates_collections=None, epsilon=1e-5, scale=True)
            conv1_ir = _lrelu(conv1_ir)
        with tf.variable_scope('layer2'):
            weights = tf.get_variable("w2", initializer=tf.constant(reader.get_tensor('fusion_model/layer2/w2')))
            bias = tf.get_variable("b2", initializer=tf.constant(reader.get_tensor('fusion_model/layer2/b2')))
            conv2_ir = tf.contrib.layers.batch_norm(
                tf.nn.conv2d(conv1_ir, weights, strides=[1, 1, 1, 1], padding='VALID') + bias, decay=0.9,
                updates_collections=None, epsilon=1e-5, scale=True)
            conv2_ir = _lrelu(conv2_ir)
        with tf.variable_scope('layer3'):
            weights = tf.get_variable("w3", initializer=tf.constant(reader.get_tensor('fusion_model/layer3/w3')))
            bias = tf.get_variable("b3", initializer=tf.constant(reader.get_tensor('fusion_model/layer3/b3')))
            conv3_ir = tf.contrib.layers.batch_norm(
                tf.nn.conv2d(conv2_ir, weights, strides=[1, 1, 1, 1], padding='VALID') + bias, decay=0.9,
                updates_collections=None, epsilon=1e-5, scale=True)
            conv3_ir = _lrelu(conv3_ir)
        with tf.variable_scope('layer4'):
            weights = tf.get_variable("w4", initializer=tf.constant(reader.get_tensor('fusion_model/layer4/w4')))
            bias = tf.get_variable("b4", initializer=tf.constant(reader.get_tensor('fusion_model/layer4/b4')))
            conv4_ir = tf.contrib.layers.batch_norm(
                tf.nn.conv2d(conv3_ir, weights, strides=[1, 1, 1, 1], padding='VALID') + bias, decay=0.9,
                updates_collections=None, epsilon=1e-5, scale=True)
            conv4_ir = _lrelu(conv4_ir)
        with tf.variable_scope('layer5'):
            weights = tf.get_variable("w5", initializer=tf.constant(reader.get_tensor('fusion_model/layer5/w5')))
            bias = tf.get_variable("b5", initializer=tf.constant(reader.get_tensor('fusion_model/layer5/b5')))
            conv5_ir = tf.nn.conv2d(conv4_ir, weights, strides=[1, 1, 1, 1], padding='VALID') + bias
            conv5_ir = tf.nn.tanh(conv5_ir)
    return conv5_ir